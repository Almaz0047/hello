import colorama
from colorama import Fore
def main():
    print(Fore.RED + "Hello!" + colorama.Fore.RESET)


if __name__ == '__main__':
    main()
